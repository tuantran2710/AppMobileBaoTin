import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:http/http.dart' as http;


class ScanBarcode extends StatelessWidget {
  final int userId;
  final String tokenLogin;
  final int compStoreId;

  ScanBarcode({
    super.key,
    required this.userId,
    required this.tokenLogin,
    required this.compStoreId
  });

  final String url = "http://125.253.121.179/CommonService.svc/";
  final String scanUrl = "Tree/Scan?id=";

  scanTree(int id) async {
    var result = await http.post(Uri.parse(url + scanUrl + id.toString() + "&compStoreId=" + compStoreId.toString() + "&userId=" + userId.toString() + "&token=" + tokenLogin),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        });
  }
  String _scanBarcode = 'Unknown';


  Future<void> scanQR() async {
    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          '#ff6666', 'Cancel', true, ScanMode.QR);
      print(barcodeScanRes);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    // if (!mounted) return;
    //
    // setState(() {
      _scanBarcode = barcodeScanRes;
    String tmp =_scanBarcode.substring(0,_scanBarcode.indexOf('\r\n'));
    tmp = tmp.substring(tmp.indexOf(':')+1);
    scanTree(int.parse(tmp));
    // });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
            appBar: AppBar(title: const Text('Quét QRCode Cây')),
            body: Builder(builder: (BuildContext context) {
              return Container(
                  alignment: Alignment.center,
                  child: Flex(
                      direction: Axis.vertical,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        // ElevatedButton(
                        //     onPressed: () => scanBarcodeNormal(),
                        //     child: Text('Start barcode scan')),
                        ElevatedButton(
                            onPressed: () => scanQR(),
                            child: Text('Quét QRCode')),
                        // ElevatedButton(
                        //     onPressed: () => startBarcodeScanStream(),
                        //     child: Text('Start barcode scan stream')),
                        Text('Kết quả : $_scanBarcode\n',
                            style: TextStyle(fontSize: 20)),

                      ]));
            }));
  }
}
