import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'outputlist.dart';
import 'view.dart';

class PDAScanBarcode extends StatefulWidget {
  final int userId;
  final String tokenLogin;
  final int compStoreId;
  final String compStoreCode;
  final String compStoreCustomer;
  final String compStorePurpose;

  final int fromForm;

  const PDAScanBarcode(
      {super.key,
      required this.userId,
      required this.tokenLogin,
      required this.compStoreId,
      required this.compStoreCode,
      required this.compStoreCustomer,
      required this.compStorePurpose, required this.fromForm});

  final String url = "http://125.253.121.179/CommonService.svc/";
  final String scanUrl = "Tree/Scan?id=";

  Future<String> scanTree(int id) async {
    if (id <= 0) return 'Cây không hợp lệ.';
    var result = await http.post(
        Uri.parse(url +
            scanUrl +
            id.toString() +
            "&compStoreId=" +
            compStoreId.toString() +
            "&userId=" +
            userId.toString() +
            "&token=" +
            tokenLogin),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        });
    int res = int.parse(result.body);
    if (res > 0)
      return 'Cây hợp lệ.';
    else
      return 'Cây không hợp lệ.';
  }

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<PDAScanBarcode> {
  static const MethodChannel methodChannel =
      MethodChannel('baotin.pda.qrcode/scan');
  static const EventChannel eventChannel =
      EventChannel('baotin.pda.qrcode/get');

  //String _scanStatus = 'Không thể đọc QRCode.';
  String _qrCode = '';
  String _result = '';
  int _id = 0;

  Future<void> _scanQRCode() async {
    try {
      await methodChannel.invokeMethod('scanQRCode');
    } on PlatformException {}
    setState(() {


    });
  }

  @override
  void initState() {
    super.initState();
    eventChannel.receiveBroadcastStream().listen(_onEvent, onError: _onError);
  }

  void _onEvent(Object? event) {
    setState(() {
      _qrCode = "${event}";
      int pos = _qrCode.indexOf('\r\n');
      String tmp;
      if (pos>-1)
        tmp = _qrCode.substring(0, _qrCode.indexOf('\r\n'));
      else
        tmp = _qrCode;
      tmp = tmp.substring(tmp.indexOf(':') + 1);
      _id = int.parse(tmp);
      //if (isChecked) _result = widget.scanTree(_id) as String;
    });
  }

  void _onError(Object error) {
    setState(() {
      _qrCode = 'Không thể đọc QRCode.';
    });
  }
  bool isChecked = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomSheet: Text(
          "CTCP PHẦN MỀM & CÔNG NGHỆ TỰ ĐỘNG 4.0 BẢO TÍN\nHOTLINE: 0817.789.789 - 0787.979.979\nURL: https://baotinsoftware.vn/\nEMAIL:baotinsoftware@gmail.com",
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        appBar: AppBar(
            title: const Text('Quét QRCode Cây',
                style: TextStyle(fontFamily: 'times new roman')),
          leading: new IconButton(
            icon: new Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () {
              switch(widget.fromForm)
              {
                case 1:
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              OutputList(userId: widget.userId, tokenLogin: widget.tokenLogin)));
                  break;
                case 2:
                  Navigator.pop(context, true);
                  break;
                case 3:
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                          builder: (context) => View(
                              userId: widget.userId,
                              tokenLogin: widget.tokenLogin,
                              compStoreId: widget.compStoreId,
                              code: widget.compStoreCode,
                              customer: widget.compStoreCustomer,
                              purpose: widget.compStorePurpose)), (route) => false);
                  break;
              }
            },
          ),
        ),


        body: Builder(builder: (BuildContext context) {
          return Container(
              alignment: Alignment.centerLeft,
              child: Flex(
                  direction: Axis.vertical,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // ElevatedButton(
                    //     onPressed: () => scanBarcodeNormal(),
                    //     child: Text('Start barcode scan')),
                    Text(
                        'Quét cây cho mã phiếu :\n' +
                            widget.compStoreCode +
                            '\n' +
                            widget.compStoreCustomer +
                            '\n' +
                            widget.compStorePurpose,
                        style: TextStyle(
                            fontSize: 20, fontFamily: 'times new roman')),
                    SizedBox(height: 20),
                    ElevatedButton(
                        onPressed: () {

                          _scanQRCode();
                          // if (isChecked && _id>0)
                          //   widget.scanTree(_id).then((String result) {
                          //     setState(() {
                          //       _result = result;
                          //       _id = 0;
                          //       //_qrCode = '';
                          //     });
                          //   });
                        },
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //         builder: (context) => PDAScanBarcode(
                          //           userId: widget.userId,
                          //           tokenLogin: widget.tokenLogin,
                          //           compStoreId: widget.compStoreId,
                          //           compStoreCode: widget.compStoreCode,
                          //           compStoreCustomer: widget.compStoreCustomer,
                          //           compStorePurpose: widget.compStorePurpose,
                          //           fromForm: widget.fromForm,
                          //         )));
                          //Navigator.pop(context, true);

                        child: Text('Quét QRCode',
                            style: TextStyle(
                                fontFamily: 'times',
                                fontWeight: FontWeight.bold))),
                    // ElevatedButton(
                    //     onPressed: () => startBarcodeScanStream(),
                    //     child: Text('Start barcode scan stream')),
                    SizedBox(height: 20),
                    Text('QRCode:\n$_qrCode',
                        style: TextStyle(
                            fontSize: 20, fontFamily: 'times new roman')),
                    SizedBox(height: 20),
                    Text('Kết quả:\n$_result',
                        style: TextStyle(
                            fontSize: 20, fontFamily: 'times new roman')),
                    CheckboxListTile(
                checkColor: Colors.white,
                title: Text("Bạn có muốn tự động thêm cây sau khi quét QRCode?"),
                value: isChecked,
                onChanged: (bool? value) {
                  setState(() {
                    isChecked = value!;
                  });
                },
              ),
                    ElevatedButton(
                        onPressed: !isChecked? () {
                            widget.scanTree(_id).then((String result) {
                              setState(() {
                                _result = result;
                                _id = 0;
                                //_qrCode = '';
                              });
                            });
                            }:null,
                        child: Text('Thêm Cây',
                            style: TextStyle(
                                fontFamily: 'times new roman',
                                fontWeight: FontWeight.bold,
                                fontSize: 15))),
                    // ElevatedButton(
                    //     onPressed: () => startBarcodeScanStream(),
                    //     child: Text('Start barcode scan stream')),
                    SizedBox(height: 20),
                  ]));
        }));
  }
}
