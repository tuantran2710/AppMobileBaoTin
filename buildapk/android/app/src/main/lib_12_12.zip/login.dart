import 'dart:convert';
import 'dart:async';
import 'outputlist.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class LoginPage extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  var rememberValue = false;
  final String url = "http://125.253.121.179/SecurityService.svc/Security/";
  final String tokenUrl =
      "GetToken?publicKey=BAOTINPUBLICKEY_123456789&secretKey=BAOTINSECRETKEY_123456789";
  final String loginUrl = "Login?";
  late String token;
  late int userId;

  Future<String> login(String userName, String password) async {
    var result = await http.get(Uri.parse(url + tokenUrl));
    String getToken = json.decode(result.body)['accesstoken'];
    if (getToken.length > 0) {
      result = await http.get(Uri.parse(url +
          loginUrl +
          "userName=" +
          userName +
          "&password=" +
          password +
          "&token=" +
          getToken));
      dynamic obj = json.decode(result.body);
      if (obj['islogin_success'] == 'false')
        return "";
      else {
        token = obj['token_loginsuccess'];
        userId = obj["id"];

        return token;
      }
    } else
      return "";
  }

  TextEditingController txtUsername = TextEditingController();
  TextEditingController txtPassword = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: SafeArea(
          child: Center(
            child: Column(
              children: [
                SizedBox(
                  height: 30,
                ),
                Image.asset('images/baotin.jpg'),
                SizedBox(
                  height: 20,
                ),
                Container(
                  height: 560,
                  width: 360,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 160, 206, 244),
                      borderRadius: BorderRadius.circular(20)),
                  child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          Icon(
                            Icons.key,
                            size: 50,
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(10)),
                              child: TextFormField(
                                  controller: txtUsername,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Nhập tài khoản đăng nhập đúng.';
                                    }
                                    return null;
                                  },
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: 'Tài khoản',
                                  )),
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.black,
                                  borderRadius: BorderRadius.circular(10)),
                              child: TextFormField(
                                controller: txtPassword,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Nhập mật khẩu đúng.';
                                  }
                                  return null;
                                },
                                obscureText: true,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintText: 'Mật khẩu',
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          ElevatedButton.icon(
                            icon: Icon(Icons.check),
                            label: Text("Đăng nhập",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 15)),
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                login(txtUsername.text, txtPassword.text)
                                    .then((String result) {
                                  if (result.length > 0) {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => OutputList(
                                                userId: userId,
                                                tokenLogin: token)));
                                  }
                                });
                              }
                            },
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Column(
                                  children: [
                                    Container(
                                      width: 180,
                                      height: 180,
                                      child: Row(children: [
                                        Image.asset('images/sp1.png')
                                      ]),
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 70),
                                  child: Container(
                                    width: 180,
                                    height: 180,
                                    child: Row(children: [
                                      Image.asset('images/sp2.png'),
                                    ]),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      )),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
